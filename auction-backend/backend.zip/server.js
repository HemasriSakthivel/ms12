const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');
const argon2 = require('argon2');

// Import the User model
const User = require('./models/User');
const Admin = require('./models/Admin');
const Bidder = require('./models/Bidder');
const Auctioneer = require('./models/Auctioneer');

const app = express();

// Middleware
app.use(cors());
app.use(bodyParser.json());

// MongoDB Connection (No .env file, hardcoded connection string)
const MONGO_URI = 'mongodb://127.0.0.1:27017/auction_bazaar'; // Replace with your MongoDB URI if necessary
mongoose.connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('MongoDB connection error:', err));

// Routes
/*
// User Registration
app.post('/register', async (req, res) => {
  try {
    const { name, username, email, password, role } = req.body;

    // Validate required fields
    if (!name || !username || !email || !password || !role) {
      return res.status(400).send({ error: 'All fields are required' });
    }

    // Create and save the user
    const user = new User({ name, username, email, password, role });
    await user.save();

    res.status(201).send({ message: 'User created successfully!' });
  } catch (err) {
    res.status(400).send({ error: err.message });
  }
});*/


// Registration API
app.post('/register', async (req, res) => {
  const { name, username, email, password, role } = req.body;

  try {
    // Check if the user already exists
    const existingUser = await User.findOne({ email });

    // If the user exists, check the bidder and auctioneer values
    if (existingUser) {
      if (existingUser.bidder !== null && existingUser.auctioneer !== null) {
        return res.status(400).send({ error: 'User already registered as both Bidder and Auctioneer' });
      }

      // If role is Bidder and bidder is null, register the user as a Bidder
      if (role === 'Bidder' && existingUser.bidder === null) {
        const bidder = new Bidder({ userId: existingUser._id });
        await bidder.save();
        existingUser.bidder = bidder._id;
        await existingUser.save();
        return res.status(200).send({ message: 'User registered as Bidder successfully!' });
      }

      // If role is Auctioneer and auctioneer is null, register the user as an Auctioneer
      if (role === 'Auctioneer' && existingUser.auctioneer === null) {
        const auctioneer = new Auctioneer({ userId: existingUser._id });
        await auctioneer.save();
        existingUser.auctioneer = auctioneer._id;
        await existingUser.save();
        return res.status(200).send({ message: 'User registered as Auctioneer successfully!' });
      }

      // If the user is trying to register for a role they already have, return an error
      return res.status(400).send({ error: `User already registered as ${existingUser.bidder ? 'Bidder' : ''} ${existingUser.auctioneer ? 'Auctioneer' : ''}` });
    }

    // If the user doesn't exist, proceed with registration
    //const hashedPassword = await bcrypt.hash(password, 10);

    // If the role is Admin, store the data in Admin collection
    if (role === 'admin') {
      const admin = new Admin({
        name,
        username,
        email,
        password//: hashedPassword,
      });
      await admin.save();
      return res.status(201).send({ message: 'Admin registered successfully!' });
    }

    // Register as Bidder or Auctioneer - Store data in User collection
    const user = new User({
      name,
      username,
      email,
      password,//: hashedPassword,
      bidder: null,
      auctioneer: null
    });

    // If the role is Bidder, create a Bidder document and assign it to the user
    if (role === 'bidder') {
      const bidder = new Bidder({ userId: user._id });
      await bidder.save();
      user.bidder = bidder._id;
    } 
    // If the role is Auctioneer, create an Auctioneer document and assign it to the user
    else if (role === 'auctioneer') {
      const auctioneer = new Auctioneer({ userId: user._id });
      await auctioneer.save();
      user.auctioneer = auctioneer._id;
    }

    await user.save();
    res.status(201).send({ message: 'User registered successfully!' });

  } catch (err) {
    res.status(400).send({ error: err.message });
  }
});


/*
// User Login
app.post('/login', async (req, res) => {
  try {
    const { email, password, role } = req.body;

    // Find user by email
    const user = await User.findOne({ email });

    // Check if user exists and if the password is valid
    if (!user || !await user.isValidPassword(password)) {
      return res.status(400).send({ error: 'Invalid email or password' });
    }

    // Check if the role matches
    if (user.role !== role) {
      return res.status(400).send({ error: 'Role does not match' });
    }

    // If everything is valid, send response with name and success message
    res.status(200).send({ name: user.username, role: user.role, message: 'Login successful' });
  } catch (err) {
    res.status(400).send({ error: err.message });
  }
});*/

// Login API
app.post('/login', async (req, res) => {
  const { email, password, role } = req.body;

  try {
    // Check if the role is Admin
    if (role === 'admin') {
      const admin = await Admin.findOne({ email });
      if (!admin) {
        return res.status(400).send({ error: 'Invalid email or password' });
      }

      const isMatch = await argon2.compare(password, admin.password);
      if (!isMatch) {
        return res.status(400).send({ error: 'Invalid email or password' });
      }

      // const token = generateToken(admin._id);
      return res.status(200).send({
        message: 'Login successful',
        // token,
        user: {
          username: admin.username,
          email: admin.email,
          name: admin.name,
          profilePicture: admin.profilePicture,
          phone: admin.phone,
          permissions: admin.permissions,
        }
      });
    }

    // Check if the role is User (Bidder or Auctioneer)
    if (role === 'bidder' || role === 'auctioneer') {
      console.log("waiting");
      const user = await User.findOne({ email });
      console.log("waiting");
      if (!user) {
        console.log("waiting3");
        return res.status(400).send({ error: 'Invalid email or password3' });
      }

      const isMatch = await argon2.verify(password, user.password);
      if (!isMatch) {
        console.log("waiting34");
        return res.status(400).send({ error: 'Invalid email or password1' });
      }

      // If role is Bidder, ensure user has a bidder account
      if (role === 'bidder' && user.bidder === null) {
        return res.status(400).send({ error: 'User is not registered as a Bidder' });
      }

      // If role is Auctioneer, ensure user has an auctioneer account
      if (role === 'auctioneer' && user.auctioneer === null) {
        return res.status(400).send({ error: 'User is not registered as an Auctioneer' });
      }

      const token = generateToken(user._id);
      return res.status(200).send({
        message: 'Login successful',
        token,
        user: {
          username: user.username,
          email: user.email,
          name: user.name,
          profilePicture: user.profilePicture,
          phone: user.phone,
          bidder: user.bidder,
          auctioneer: user.auctioneer,
        }
      });
    }

    // If role is not provided or incorrect
    return res.status(400).send({ error: 'Invalid role specified' });
  } catch (err) {
    res.status(500).send({ error: 'Server error' });
  }
});



// Start Server
const PORT = 5000; // Hardcoded port value
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
