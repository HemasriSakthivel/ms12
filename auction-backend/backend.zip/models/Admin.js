const mongoose = require('mongoose');

const adminSchema = new mongoose.Schema({
  name: { type: String, required: true }, 
  username: { type: String, required: true, unique: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  profilePicture: { type: String },
  phone: { type: String },
  permissions: [{
    type: String,
    enum: ['Manage Auctions', 'View Users', 'Manage Users', 'View Reports', 'Delete Auctions', 'Edit Auctions'],
    default: ['Manage Auctions', 'View Users', 'Manage Users', 'View Reports', 'Delete Auctions', 'Edit Auctions']
  }]
});

module.exports = mongoose.model('Admin', adminSchema);
